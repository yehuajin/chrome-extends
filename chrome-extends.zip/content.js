// console.log(JSON.stringify(localStorage));
// console.log(JSON.stringify(sessionStorage));
// console.log(document.cookie);
chrome.runtime.onMessage.addListener(function (message) {
  const params = {
    domain: ".liepin.com",
    url: "http://lpt.liepin.com",
    cookie: JSON.stringify(message),
  };
  window.opener.postMessage(params, "*");
  // (message || []).forEach((item) => {
  //   console.log(item.name, item.value);
  //   document.cookie = `${item.name}=${escape(item.value)};path=/`;
  // });
  // var xhr = new XMLHttpRequest();
  // xhr.open(
  //   "POST",
  //   "https://apilpt.liepin.com/api/com.liepin.searchfront4r.b.search",
  //   true
  // );
  // xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  // const form = new FormData();
  // form.set("cvSearchConditionInputVo", {
  //   suggestKey: "0fccf28f1e5efb38139a906d6a5045b6",
  //   searchRefer: "1",
  //   cvSearchForm: "0",
  //   keysRelation: "",
  //   searchKey: "",
  //   filterKey: "",
  //   degrade: "",
  //   csCreateTimeFlag: "",
  //   csCreateTime: "",
  //   csId: "",
  //   curPage: 0,
  //   keys: "java",
  //   searchLevel: "",
  //   dqs: "",
  //   wantDqs: "",
  //   workyears: "0,99",
  //   eduLevels: [],
  //   industrys: "",
  //   jobtitles: "",
  //   wantIndustrys: "",
  //   wantJobTitles: "",
  //   updateDate: "",
  //   userStatus: "",
  //   yearSalarylow: "",
  //   yearSalaryhigh: "",
  //   wantYearSalaryLow: "",
  //   wantYearSalaryHigh: "",
  //   sex: "",
  //   compKind: "",
  //   age: "",
  //   special: "",
  //   sortflag: "",
  //   edulevel_tz: "",
  //   schoolKind: "",
  //   abroadEdu: "",
  //   abroadExp: "",
  //   manageExp: "",
  //   language_skills: "",
  //   language_content: "",
  //   filterRead: "",
  //   filterDownload: "",
  //   lastWork: "",
  //   titleKeys: "",
  //   titleSearchFilter: "0",
  //   companyKeys: "",
  //   compSearchFilter: "0",
  //   interactiveVersion: "v2",
  //   jobId: "",
  // });
  // form.set('logForm', { "ckId": "44836ace-9abe-42ba-9650-1ee2bf26c2ce", "searchScene": "button" })
  // xhr.send(form);
  // xhr.onreadystatechange = function () {
  //   if (xhr.readyState == 4) {
  //     // JSON解析器不会执行攻击者设计的脚本.
  //     console.log(xhr.responseText)
  //   }
  // };
  // xhr.send();
});
